window.onload = function() {
    setTimeout(scrollToBottom, 5);
}

function scrollToBottom(){
    window.scrollTo(0,document.body.scrollHeight);
}

